# Building a Voice Call Intelligence Pipeline with Deepgram and Claude

> How to transform unstructured phone conversations into structured, actionable business intelligence using a two-stage AI extraction architecture.

**Author:** Javad Gougerdie — CTO & AI Systems Architect

---

## The Problem: Business Intelligence Trapped in Audio

Every business runs on phone calls. Sales conversations, customer support interactions, vendor negotiations, project check-ins — critical decisions happen verbally and disappear the moment the call ends. Action items get forgotten. Deadlines slip. Customer frustration goes undetected until it's too late.

The standard fix — manual note-taking or post-call summaries — doesn't scale. Human recall is unreliable, subjective, and inconsistent across team members. What's needed is a deterministic system that converts raw audio into structured, machine-readable business data — automatically, every time.

*The goal is not transcription. Transcription is a commodity. The goal is structured intelligence extraction — turning messy human conversation into validated, actionable data objects.*

## Architecture Overview: The Two-Stage Pipeline

The solution is a two-stage extraction architecture. Each stage handles a fundamentally different problem domain, and separating them is critical to reliability:

- **Stage 1: Speech-to-Text** — Deepgram Nova-2 converts raw audio into accurate text with smart formatting
- **Stage 2: AI Extraction** — Claude 3.5 Sonnet parses the transcript and outputs a strictly validated JSON schema containing action items, customer sentiment, and key dates

This separation follows a core production AI principle: **never ask one component to solve two fundamentally different problems.** Audio signal processing and semantic reasoning require entirely different architectures.

![Voice Call Intelligence Pipeline](./diagram-pipeline.png)
*Voice Call Intelligence Pipeline — from raw audio through speech-to-text transcription to schema-validated structured JSON output*

## Stage 1: Deepgram Nova-2 — Speech-to-Text Engine

Deepgram's Nova-2 model was selected for production use because of three specific properties:

- **Accuracy on conversational audio** — handles overlapping speakers, background noise, and informal speech patterns
- **Smart formatting** — automatic punctuation, capitalization, and number formatting reduce downstream preprocessing
- **Low latency** — processes files quickly enough for near-real-time pipeline execution

*The transcription layer is deliberately simple. Its only job is faithful audio-to-text conversion. All interpretation happens downstream.*

## Stage 2: Claude 3.5 Sonnet — AI Extraction Engine

The second stage is where unstructured conversation becomes structured business intelligence. Claude receives the raw transcript and a strict extraction prompt, returning a schema-validated JSON object with three data categories:

### Action Items
Every task mentioned in the conversation is extracted with an assignee and clear task description — capturing both explicit commitments and implicit obligations.

### Customer Sentiment
A single classification label (Positive, Neutral, or Negative) with a one-sentence justification grounded in specific transcript evidence. A concrete, auditable assessment that operations teams can act on immediately.

### Key Dates and Commitments
Every deadline, delivery window, follow-up date, or time-sensitive commitment mentioned in the call is extracted with its surrounding context.

## Why Zero Temperature Matters

The extraction engine runs at **temperature 0**. In structured data extraction pipelines, you need deterministic, reproducible outputs. The same transcript processed twice should produce the same JSON. Creative variation — useful in content generation — is catastrophic in data extraction.

*Temperature 0 + strict system prompt + schema enforcement = deterministic extraction. The model is a structured reasoning engine, not a conversational agent.*

## Production Resilience: Error Handling and Fallbacks

- **Transcription failures** — runtime errors from Deepgram are caught and raised explicitly before extraction
- **JSON parsing failures** — raw response captured for debugging rather than silently dropping data
- **API processing failures** — connection timeouts, rate limits, and service outages caught with descriptive error messages
- **File validation** — pipeline checks for file existence before processing

Each failure mode produces a structured error object rather than crashing the pipeline.

## Integration Patterns

The pipeline's JSON output is designed for direct integration with downstream business systems:

- **CRM ingestion** — action items and sentiment feed into GoHighLevel, HubSpot, or Salesforce
- **Project management** — key dates sync to Asana, Monday.com, or Jira
- **Alerting** — negative sentiment triggers immediate Slack notifications
- **Analytics** — aggregated sentiment trends surface systemic customer experience issues
- **Compliance** — full transcript + structured extraction creates an auditable record

## Key Takeaway

Voice data is the largest untapped source of business intelligence in most organizations. The critical insight is **separation of concerns**: let the speech model handle acoustics, let the language model handle semantics, and enforce strict schema validation at the boundary.

---

## Technologies

`Deepgram Nova-2` · `Claude 3.5 Sonnet` · `Python` · `JSON Schema Validation` · `GoHighLevel` · `Slack` · `REST APIs`
