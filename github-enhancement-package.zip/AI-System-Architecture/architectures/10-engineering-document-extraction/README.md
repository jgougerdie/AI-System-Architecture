# Why LLM-Only Approaches Fail in Engineering Document Extraction — and What Works Instead

> A deterministic-first architecture for reliable data extraction from HVAC blueprints, CAD files, and complex engineering documents.

**Author:** Javad Gougerdie — CTO & AI Systems Architect

---

## Introduction

Engineering teams working with complex documents such as HVAC blueprints, architectural drawings, and CAD files often attempt to use large language models (LLMs) as end-to-end extraction systems. At first glance, this approach appears efficient: upload a PDF, ask the model to extract structured data, and receive a usable output.

However, in real-world production environments, this approach consistently breaks down. The issue is not the capability of LLMs themselves, but the mismatch between **probabilistic language models and structurally precise engineering data.**

## The Core Problem: Documents Are Not Text

HVAC blueprints and CAD files are fundamentally **geometric and relational systems**, not linear text documents. They contain:

- Vector geometry (lines, arcs, polylines)
- Layered organizational structures
- Spatial relationships (adjacency, distance, alignment)
- Symbolic representations (ducts, fittings, equipment)
- Embedded annotations and measurements

When these files are converted into flat text or images for LLM ingestion, a critical loss occurs: **the structural truth of the document is destroyed.** This leads to hallucinations, inconsistent parsing, and unstable outputs.

## Why LLM-Only Pipelines Fail

LLMs are optimized for reasoning over language, not geometry or deterministic structure. Common failure modes:

- Misinterpretation of spatial relationships (e.g., connecting unrelated ducts)
- Loss of scale and coordinate integrity
- Inconsistent entity classification across similar drawings
- Non-reproducible outputs between runs
- Hidden ambiguity amplification (small OCR errors cascade into structural errors)

*LLMs "understand language," but HVAC systems are not language — they are structured engineering graphs.*

## The Correct Approach: Deterministic-First Architecture

Instead of: `Document → LLM → Structured Output`

The correct architecture is: `Document → Deterministic Extraction → Structured Model → Controlled LLM Reasoning → Output`

![Engineering Document Extraction Pipeline](./diagram-extraction-pipeline.png)
*Deterministic-first architecture — from raw engineering documents through controlled LLM reasoning to structured output*

### 1. Deterministic Extraction Layer
No interpretation happens early in the pipeline:
- PDF structure parsing (text vs vector separation)
- CAD extraction (DWG/DXF: geometry, layers, blocks)
- Targeted OCR only where necessary

### 2. Structural Decomposition Layer
Raw fragments organized into meaningful groups:
- Zones and spatial regions
- System-level segmentation (HVAC networks)
- Repeated component detection
- Spatial relationship mapping

### 3. Schema-Based Representation Layer
Entities formalized into strict schemas:
- Ducts → structured flow paths
- Equipment → labeled system nodes
- Annotations → anchored references
- Dimensions → validated measurements

All entities mapped with traceability back to source geometry.

### 4. Controlled LLM Integration
LLMs introduced **only at this stage**, operating strictly on structured data for:
- Ambiguity resolution
- Semantic classification
- Edge-case interpretation

**Constraints:** No raw PDF or CAD input. Schema-validated input/output only. Task-specific, isolated reasoning.

### 5. Output Layer for Engineering Systems
Final outputs designed for real-world usage:
- CSV / Excel for estimation workflows
- JSON for APIs and databases
- BIM-compatible structured datasets

Each output is traceable, reproducible, and validation-ready.

## Key Insight

> Success in engineering document AI does not come from stronger prompts — it comes from **reducing ambiguity before the model is ever involved.**

## Conclusion

The reliable approach is to treat LLMs as **secondary reasoning tools**, not primary extraction engines. By separating deterministic extraction, structural modeling, and controlled semantic reasoning, we achieve systems that are not only accurate, but also stable enough for production engineering environments.

---

## Technologies

`CAD Processing (DWG/DXF)` · `OCR` · `PDF Parsing` · `LLM Reasoning` · `Schema Validation` · `BIM Integration` · `Python`
